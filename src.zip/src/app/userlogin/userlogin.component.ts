import { Component, OnInit } from '@angular/core';
import { FormBuilder,FormGroup,FormControl,Validators,NgForm } from '@angular/forms';
import { CrudService } from '../crud.service';
import { AuthServiceService} from '../auth-service.service';
import { Router } from '@angular/router';
import { TransferService } from '../transfer.service';

@Component({
  selector: 'app-userlogin',
  templateUrl: './userlogin.component.html',
  styleUrls: ['./userlogin.component.css']
})
export class UserloginComponent implements OnInit {
  signupForm:FormGroup;    
  Email:string="";  
  Password:string="";
  msgRegister:string="";

  constructor(private frmbuilder:FormBuilder, private crud:CrudService, private auth:AuthServiceService, private router:Router, private trans:TransferService) {
  	this.signupForm=frmbuilder.group({  
    Emailid:new FormControl(),  
    userpassword:new FormControl()  
    });  
  }

  ngOnInit() {
  	this.signupForm= this.frmbuilder.group({  
        Emailid:['',[Validators.required,Validators.email]],  
        userpassword:['',Validators.required]  
    })  
  }

  PostData(signupForm:NgForm)  
  {  
  	var email = signupForm.value.Emailid;
  	var password = signupForm.value.userpassword;
    console.log(email);
    console.log(password);
    console.log(signupForm.value);
    // this.crud.insert("users", signupForm.value).subscribe(
    // 	(res) => {
    // 		this.msgRegister = "User Added";
    // 	}
    // )
    // this.crud.insertPHP("users.php", signupForm.value).subscribe(
    // 	(res) => {
    // 		this.msgRegister = "User Added";
    // 	}
    // )
    this.crud.select("users").subscribe(
    	(res) => {
    		var cnt = 0;
    		for (var key in res) {
    			if(res[key].Emailid == email && res[key].userpassword==password){
                    cnt++;
                    break;
    			}
    		}
    		if(cnt > 0) {
    			//this.msgRegister = "ok";
          this.auth.setSession(email);
          this.trans.shareUserData({userEmail:email});
          this.router.navigate(['/']);
    		} else {
    			this.msgRegister = "Invalid credentails";
    		}
    	}
    )
  }  

}
