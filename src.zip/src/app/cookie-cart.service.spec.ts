import { TestBed } from '@angular/core/testing';

import { CookieCartService } from './cookie-cart.service';

describe('CookieCartService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: CookieCartService = TestBed.get(CookieCartService);
    expect(service).toBeTruthy();
  });
});
