import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { CrudService } from '../crud.service';
import { CookieCartService } from '../cookie-cart.service';

@Component({
  selector: 'app-main',
  templateUrl: './main.component.html',
  styleUrls: ['./main.component.css']
})
export class MainComponent implements OnInit {
  public products:any;
  
  constructor(private crud:CrudService, private cart:CookieCartService) {
  	this.crud.select("product").subscribe(
  		(response) => {
        //for(let ans in response)
  			this.products = response;
        console.log("products");
  			console.log(response);
  		},
  		(err) => {
  			console.log(err);
  		}
  	);
  }

  ngOnInit() {
  }

  addToCart(id, ev) {
    ev.preventDefault();
    this.cart.add(id);
  }

}
