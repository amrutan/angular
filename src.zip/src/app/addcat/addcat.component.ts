import { Component, OnInit } from '@angular/core';
import { CrudService } from '../crud.service';

@Component({
  selector: 'app-addcat',
  templateUrl: './addcat.component.html',
  styleUrls: ['./addcat.component.css']
})
export class AddcatComponent implements OnInit {

  constructor(private crud:CrudService) { }

  ngOnInit() {
  }

  add_category(data) {
  	if (data.length > 0) {
        this.crud.insert("category", {title:data}).subscribe(
        	(response) => {
        		console.log(response);
        	}
        )
  	}
  }

}
