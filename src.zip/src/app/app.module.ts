import { BrowserModule } from '@angular/platform-browser';
import { HttpClientModule } from '@angular/common/http';
import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { CookieService } from 'ngx-cookie-service';

import { AfterLoginGuard} from './after-login.guard';
import { BeforeLoginGuard} from './before-login.guard';

import { AppComponent } from './app.component';
import { HeaderComponent } from './header/header.component';
import { SliderComponent } from './slider/slider.component';
import { LeftComponent } from './left/left.component';
import { MainComponent } from './main/main.component';
import { FooterComponent } from './footer/footer.component';
import { CartComponent } from './cart/cart.component';
import { LoginComponent } from './login/login.component';
import { FilterComponent } from './filter/filter.component';
import { AddcatComponent } from './addcat/addcat.component';
import { AddbrandComponent } from './addbrand/addbrand.component';
import { AddcategoryComponent } from './addcategory/addcategory.component';
import { UserloginComponent } from './userlogin/userlogin.component';
import { LogoutComponent } from './logout/logout.component';

const appRoutes = [
    {path: 'cartPage', component: CartComponent},
    {path: 'loginPage', component: LoginComponent, canActivate: [AfterLoginGuard]},
    {path: 'userLoginPage', component: UserloginComponent, canActivate: [AfterLoginGuard]},
    {path: 'addCategory', component: AddcatComponent, canActivate: [BeforeLoginGuard]},
    {path: 'addBrand', component: AddbrandComponent, canActivate: [BeforeLoginGuard]},
    {path: 'logout', component: LogoutComponent, canActivate: [BeforeLoginGuard]},
    {path: '', component: MainComponent},
    {path: 'filterbyCategory/:categoryid', component: FilterComponent}
];

@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    SliderComponent,
    LeftComponent,
    MainComponent,
    FooterComponent,
    CartComponent,
    LoginComponent,
    FilterComponent,
    AddcatComponent,
    AddbrandComponent,
    AddcategoryComponent,
    UserloginComponent,
    LogoutComponent
  ],
  imports: [
    BrowserModule,
    HttpClientModule,
    RouterModule.forRoot(appRoutes),
    ReactiveFormsModule,
    FormsModule
  ],
  providers: [CookieService],
  bootstrap: [AppComponent]
})
export class AppModule { }
