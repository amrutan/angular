import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class AuthServiceService {

  constructor() { }

  setSession(email) {
  	localStorage.setItem("userEmail", email);
  }

  logout() {
  	localStorage.removeItem("userEmail");
  }

  checkUser() {
  	var ans = localStorage.getItem("userEmail");
  	return (ans == null || ans == "") ? false: true;
  }
}
