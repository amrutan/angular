import { Component, OnInit } from '@angular/core';
import { AuthServiceService } from '../auth-service.service';
import { TransferService } from '../transfer.service';
import { CookieCartService } from '../cookie-cart.service';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit {
  public status1=true;
  public status2=false;
  public emailid:any;
  public cartcnt=0;
  constructor(private auth:AuthServiceService, private trans:TransferService, private cart:CookieCartService) { 
    this.trans.object_transfer_auth.subscribe((response) =>{
      if(response =="") {
        this.status1= true;
        this.status2 = false;
        this.emailid = "";
      } else {
        this.emailid = response['userEmail'];
        this.status1 = false;
        this.status2 = true;
      }
    })

    this.trans.object_transfer_cart.subscribe((res) =>{
      this.cartcnt = res['cnt'];
    })
  }

  ngOnInit() {
  	if(this.auth.checkUser()) {
  		this.status1=false;
  		this.status2=true;
  	} else {
  		this.status1=true;
  		this.status2=false;
  	}

    this.cartcnt = this.cart.getCartCount();
  }

}
