import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { map } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class CrudService {
  url = "http://localhost:3000/";
   url1 = "http://localhost/amruta/";
  constructor(public http:HttpClient) {}
  select(tablename) {
    return this.http.get(this.url+tablename).pipe(
    	map(
    		(res) => {
    			return res;
    		}
    	)
    );
  }

  insert(tablename, data) {
    return this.http.post(this.url+tablename, data).pipe(
      map(
        (res) => {
          return res;
        }
      )
    );
  }

  insertPHP(tablename, data) {
    return this.http.post(this.url1+tablename, data).pipe(
      map(
        (res) => {
          return res;
        }
      )
    );
  }
}