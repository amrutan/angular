import { Component, OnInit } from '@angular/core';
import { AuthServiceService} from '../auth-service.service';
import { TransferService} from '../transfer.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-logout',
  templateUrl: './logout.component.html',
  styleUrls: ['./logout.component.css']
})
export class LogoutComponent implements OnInit {

  constructor(private auth:AuthServiceService, private router:Router, private trans:TransferService) {
  }

  ngOnInit() {
  	this.auth.logout();
  	this.trans.shareUserData("");
  	this.router.navigate(['/userLoginPage']);
  }

}
