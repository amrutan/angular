import { Component, OnInit } from '@angular/core';
import { CrudService } from '../crud.service';

@Component({
  selector: 'app-left',
  templateUrl: './left.component.html',
  styleUrls: ['./left.component.css']
})
export class LeftComponent implements OnInit {
  public brand:any;
  public category:any;
  constructor(private crud:CrudService) { 
     this.crud.select("brands").subscribe(
     	(response) => {
     		console.log(response);
     		this.brand = response;
     	},
     );

     this.crud.select("category").subscribe(
      (response) => {
        console.log(response);
        this.category = response;
      } 
     );
  }
  ngOnInit() {
  }
}
