import { Injectable } from '@angular/core';
import { CookieService } from 'ngx-cookie-service';
import { TransferService } from './transfer.service';

@Injectable({
  providedIn: 'root'
})
export class CookieCartService {

  constructor(private cook: CookieService, private trans:TransferService) { }
  public cartcnt = 0;

  add(id) {
  	console.log(id);
   var ans = this.cook.get("cartRecord");
   if (ans == "") {
   	this.cook.set("cartRecord", id);
   	this.cartcnt =1;
   } else {
   	var arr = ans.split("#");
   	var pos = arr.indexOf(id.toString());
    if (pos == -1) {
    	var newpro = ans+"#"+id;
    	this.cook.set("cartRecord", newpro);
    	this.cartcnt = arr.length +1; 
    } else {
    	this.cartcnt = arr.length;
    }
   }

   this.trans.sendCartCount({cnt:this.cartcnt})
  }

  getCartCount() {
  	var ans = this.cook.get("cartRecord");
  	if(ans =="") {
  		return 0;
  	} else {
  		return ans.split("#").length;
  	}
    //return this.cook.get("cartRecord").split("#").length;
  }

  getCartData() {
    var ans = this.cook.get("cartRecord");
    if (ans =="") {
      return "";
    } else {
      return ans.split("#");
    }
  }

  delete(id) {
    var cartdata = this.getCartData();
    var pos = cartdata.indexOf(id.toString());
    cartdata.splice(pos,1);
    this.cook.set("cartRecord", cartdata.join("#"));
    this.cartcnt = cartdata.length;
    this.trans.sendCartCount({cnt:this.cartcnt})
  }
}
