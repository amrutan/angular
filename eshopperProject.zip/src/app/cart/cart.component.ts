import { Component, OnInit } from '@angular/core';
import { CookieCartService } from '../cookie-cart.service';
import { CrudService } from '../crud.service';

@Component({
  selector: 'app-cart',
  templateUrl: './cart.component.html',
  styleUrls: ['./cart.component.css']
})
export class CartComponent implements OnInit {

  constructor(private cart:CookieCartService, private crud:CrudService) { }
  public products:any;
  ngOnInit() {
  	var result = this.cart.getCartData();
  	if(result.length > 0) {
  		console.log(result);

  		this.crud.select("product").subscribe((res) => {
  			var newarr = [];
  			for(var key in res) {
  				if (result.indexOf(res[key]['id'].toString())>-1){
                  newarr.push(res[key]);
  				}
  			}
  			this.products = newarr;
  		})
  	}
  }

  deleteFromCart(id, ev) {
  	ev.preventDefault();
  	this.cart.delete(id);
  	ev.target.parentNode.parentNode.parentNode.parentNode.style.display = "none";
  }

}
