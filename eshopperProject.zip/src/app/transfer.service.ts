import { Injectable } from '@angular/core';
import { Subject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class TransferService {
  public object_subject_class = new Subject();
  public object_transfer_auth = new Subject();
  public object_transfer_cart = new Subject();
  constructor() { }

  shareUserData(data) {
  	this.object_transfer_auth.next(data);
  }

  sendCartCount(data) {
   this.object_transfer_cart.next(data);
  }
}
