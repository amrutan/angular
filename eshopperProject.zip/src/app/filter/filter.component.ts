import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { CrudService } from '../crud.service';

@Component({
  selector: 'app-filter',
  templateUrl: './filter.component.html',
  styleUrls: ['./filter.component.css']
})
export class FilterComponent implements OnInit {
  public categoryId:any;
  public products:any;
  constructor(public completeUrl:ActivatedRoute, private crud:CrudService) {
  }

  ngOnInit() {
  	    this.categoryId = this.completeUrl.snapshot.params.categoryid;
        console.log(this.completeUrl);
  	    console.log(this.categoryId);
  	  	this.crud.select("product").subscribe(
  		(response) => {
  			var arr = [];
  			console.log(response);
  			for(var answer in response) {
  				if(response[answer]['catid'] == this.categoryId) {
  					arr.push(response[answer]);
  				}
  			}
  			this.products = arr;
  		},
  		(err) => {
  			console.log(err);
  		}
  	);
  }

}
