import { Component, OnInit } from '@angular/core';
import { FormBuilder,FormGroup,FormControl,Validators,NgForm } from '@angular/forms';
import { CrudService } from '../crud.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  signupForm:FormGroup;  
  FirstName:string="";    
  Email:string="";  
  Password:string="";
  msgRegister:string="";

  constructor(private frmbuilder:FormBuilder, private crud:CrudService) {
  	this.signupForm=frmbuilder.group({  
    fname:new FormControl(),   
    Emailid:new FormControl(),  
    userpassword:new FormControl()  
    });  
  }

  ngOnInit() {
  	this.signupForm= this.frmbuilder.group({  
        fname:['',Validators.compose([Validators.required,Validators.maxLength(15),Validators.minLength(1)])],  
        Emailid:['',[Validators.required,Validators.email]],  
        userpassword:['',Validators.required]  
    })  
  }

  PostData(signupForm:NgForm)  
  {  
    console.log(signupForm.value);
    // this.crud.insert("users", signupForm.value).subscribe(
    // 	(res) => {
    // 		this.msgRegister = "User Added";
    // 	}
    // )
    this.crud.insertPHP("users.php", signupForm.value).subscribe(
    	(res) => {
    		this.msgRegister = "User Added";
    	}
    )
  }  

}
